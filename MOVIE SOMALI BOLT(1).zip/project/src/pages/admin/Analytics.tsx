import React from 'react';
import { BarChart3, TrendingUp, Users, Clock } from 'lucide-react';

function Analytics() {
  const metrics = [
    {
      title: 'User Growth',
      value: '+12.5%',
      description: 'Compared to last month',
      icon: Users,
      color: 'text-blue-500'
    },
    {
      title: 'Watch Time',
      value: '245,000 hrs',
      description: 'Total this month',
      icon: Clock,
      color: 'text-green-500'
    },
    {
      title: 'Revenue',
      value: '$15,245',
      description: 'Monthly recurring revenue',
      icon: TrendingUp,
      color: 'text-red-500'
    }
  ];

  return (
    <div className="animate-fade-in">
      <h1 className="text-3xl font-bold mb-8">Analytics Overview</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {metrics.map((metric, index) => (
          <div
            key={metric.title}
            className="bg-gray-800 rounded-lg p-6 animate-slide-up"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gray-700 rounded-lg">
                <metric.icon className={`w-6 h-6 ${metric.color}`} />
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-1">{metric.value}</h3>
            <p className="text-gray-400">{metric.title}</p>
            <p className="text-sm text-gray-500 mt-2">{metric.description}</p>
          </div>
        ))}
      </div>

      {/* Chart Section */}
      <div className="bg-gray-800 rounded-lg p-6 animate-slide-up" style={{ animationDelay: '400ms' }}>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold">Viewing Trends</h2>
          <select className="bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500">
            <option>Last 7 days</option>
            <option>Last 30 days</option>
            <option>Last 90 days</option>
          </select>
        </div>
        
        <div className="h-64 flex items-end justify-between space-x-2">
          {[65, 45, 75, 50, 85, 70, 60].map((height, index) => (
            <div
              key={index}
              className="w-full bg-red-500/20 rounded-t animate-slide-up"
              style={{
                height: `${height}%`,
                animationDelay: `${500 + index * 100}ms`
              }}
            >
              <div
                className="w-full bg-red-500 rounded-t transition-all duration-500"
                style={{ height: `${height}%` }}
              />
            </div>
          ))}
        </div>
        
        <div className="flex justify-between mt-4 text-sm text-gray-400">
          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
            <span key={day}>{day}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

export default