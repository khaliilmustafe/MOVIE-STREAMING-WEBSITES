import React from 'react';
import { Film, Search, Bell, UserCircle, Play, TrendingUp, Star, Clock, Settings, Heart, Calendar, Tv } from 'lucide-react';

function Home() {
  const [isLoaded, setIsLoaded] = React.useState(false);

  React.useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className={`min-h-screen bg-gray-900 text-white ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`}>
      {/* Navigation */}
      <nav className="fixed w-full bg-gradient-to-b from-black/75 to-transparent z-50 animate-slide-down">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <div className="flex items-center animate-float">
              <Film className="w-8 h-8 text-red-500" />
              <span className="ml-2 text-2xl font-bold">SoomaaliFilm</span>
            </div>
            <div className="hidden md:flex space-x-6">
              {['Home', 'Movies', 'Series', 'TV Shows'].map((item, index) => (
                <a
                  key={item}
                  href="#"
                  className="hover:text-red-500 transition-all duration-300 transform hover:scale-110 animate-slide-down"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  {item}
                </a>
              ))}
            </div>
          </div>
          <div className="flex items-center space-x-6 animate-slide-down" style={{ animationDelay: '400ms' }}>
            <div className="relative hover-scale">
              <input
                type="text"
                placeholder="Search..."
                className="bg-gray-800 rounded-full py-2 px-4 pl-10 text-sm focus:outline-none focus:ring-2 focus:ring-red-500 transition-all duration-300"
              />
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
            <Bell className="w-6 h-6 cursor-pointer hover:text-red-500 transition-all duration-300 transform hover:scale-110" />
            <UserCircle className="w-6 h-6 cursor-pointer hover:text-red-500 transition-all duration-300 transform hover:scale-110" />
          </div>
        </div>
      </nav>

      {/* Rest of the Home component content */}
      {/* ... (keep all the existing sections from the previous App.tsx) ... */}
    </div>
  );
}

export default Home;