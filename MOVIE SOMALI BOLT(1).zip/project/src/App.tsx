import React, { useEffect, useState } from 'react';
import { Film, Search, Bell, UserCircle, Play, TrendingUp, Star, Clock, Settings, Heart, Calendar, Tv } from 'lucide-react';

function App() {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className={`min-h-screen bg-gray-900 text-white ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`}>
      {/* Navigation */}
      <nav className="fixed w-full bg-gradient-to-b from-black/75 to-transparent z-50 animate-slide-down">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <div className="flex items-center animate-float">
              <Film className="w-8 h-8 text-red-500" />
              <span className="ml-2 text-2xl font-bold">SoomaaliFilm</span>
            </div>
            <div className="hidden md:flex space-x-6">
              {['Home', 'Movies', 'Series', 'TV Shows'].map((item, index) => (
                <a
                  key={item}
                  href="#"
                  className="hover:text-red-500 transition-all duration-300 transform hover:scale-110 animate-slide-down"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  {item}
                </a>
              ))}
            </div>
          </div>
          <div className="flex items-center space-x-6 animate-slide-down" style={{ animationDelay: '400ms' }}>
            <div className="relative hover-scale">
              <input
                type="text"
                placeholder="Search..."
                className="bg-gray-800 rounded-full py-2 px-4 pl-10 text-sm focus:outline-none focus:ring-2 focus:ring-red-500 transition-all duration-300"
              />
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
            <Bell className="w-6 h-6 cursor-pointer hover:text-red-500 transition-all duration-300 transform hover:scale-110" />
            <UserCircle className="w-6 h-6 cursor-pointer hover:text-red-500 transition-all duration-300 transform hover:scale-110" />
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative h-[90vh] flex items-center animate-fade-in">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=2070&q=80"
            alt="Featured Movie"
            className="w-full h-full object-cover animate-scale-in"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent" />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <span className="text-red-500 font-semibold mb-2 inline-block animate-slide-up delay-100">FEATURED MOVIE</span>
          <h1 className="text-6xl font-bold mb-4 animate-slide-up delay-200">Hooyo Somali</h1>
          <div className="flex items-center space-x-4 mb-6 animate-slide-up delay-300">
            <span className="flex items-center"><Star className="w-4 h-4 text-yellow-500 mr-1 animate-pulse-slow" /> 4.9</span>
            <span>2024</span>
            <span>2h 15min</span>
            <span className="px-2 py-1 bg-red-500 rounded animate-pulse-slow">PREMIUM</span>
          </div>
          <p className="max-w-xl text-gray-300 mb-8 text-lg animate-slide-up delay-400">
            Experience the heartwarming story of a Somali mother's sacrifice and love for her family in this critically acclaimed drama.
          </p>
          <div className="flex space-x-4 animate-slide-up delay-500">
            <button className="flex items-center px-8 py-4 bg-red-600 rounded-lg hover:bg-red-700 transition-all duration-300 transform hover:scale-105">
              <Play className="w-5 h-5 mr-2" /> Watch Now
            </button>
            <button className="flex items-center px-8 py-4 bg-gray-800 rounded-lg hover:bg-gray-700 transition-all duration-300 transform hover:scale-105">
              <Heart className="w-5 h-5 mr-2" /> Add to Favorites
            </button>
          </div>
        </div>
      </div>

      {/* Continue Watching */}
      <section className="py-12 bg-black/30 animate-fade-in" style={{ animationDelay: '600ms' }}>
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center animate-slide-up">
              <Clock className="w-6 h-6 text-red-500 mr-2" />
              <h2 className="text-2xl font-bold">Continue Watching</h2>
            </div>
            <a href="#" className="text-red-500 hover:text-red-400 transition-all duration-300 transform hover:scale-110">View All</a>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((item, index) => (
              <div
                key={item}
                className="relative group hover-lift animate-fade-in"
                style={{ animationDelay: `${700 + index * 100}ms` }}
              >
                <div className="relative overflow-hidden rounded-lg">
                  <img 
                    src="https://images.unsplash.com/photo-1533488765986-dfa2a9939acd?auto=format&fit=crop&w=500&q=80"
                    alt="Movie"
                    className="w-full h-[200px] object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-700">
                    <div className="h-full bg-red-500 transition-all duration-300" style={{width: '70%'}} />
                  </div>
                </div>
                <div className="mt-2">
                  <h3 className="font-semibold">Somali Warriors</h3>
                  <p className="text-sm text-gray-400">Episode 4 of 10</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trending Now */}
      <section className="py-12 animate-fade-in" style={{ animationDelay: '800ms' }}>
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center animate-slide-up">
              <TrendingUp className="w-6 h-6 text-red-500 mr-2" />
              <h2 className="text-2xl font-bold">Trending Now</h2>
            </div>
            <a href="#" className="text-red-500 hover:text-red-400 transition-all duration-300 transform hover:scale-110">View All</a>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {[1, 2, 3, 4, 5, 6].map((item, index) => (
              <div
                key={item}
                className="relative group cursor-pointer hover-lift animate-fade-in"
                style={{ animationDelay: `${900 + index * 100}ms` }}
              >
                <img 
                  src="https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=500&q=80"
                  alt="Movie"
                  className="w-full h-[300px] object-cover rounded-lg transition-all duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 to-transparent rounded-lg opacity-0 group-hover:opacity-100 transition-all duration-300">
                  <div className="absolute bottom-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                    <h3 className="text-lg font-semibold">Somali Love Story</h3>
                    <div className="flex items-center text-sm text-gray-300">
                      <Star className="w-4 h-4 text-yellow-500 mr-1" />
                      <span>4.5</span>
                      <Clock className="w-4 h-4 ml-2 mr-1" />
                      <span>2h 15m</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Live TV */}
      <section className="py-12 bg-black/30 animate-fade-in" style={{ animationDelay: '1000ms' }}>
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center animate-slide-up">
              <Tv className="w-6 h-6 text-red-500 mr-2" />
              <h2 className="text-2xl font-bold">Live TV</h2>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-gray-400" />
              <span className="text-gray-400">TV Guide</span>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((item, index) => (
              <div
                key={item}
                className="bg-gray-800 rounded-lg overflow-hidden group cursor-pointer hover-lift animate-fade-in"
                style={{ animationDelay: `${1100 + index * 100}ms` }}
              >
                <div className="relative">
                  <img 
                    src="https://images.unsplash.com/photo-1495020689067-958852a7765e?auto=format&fit=crop&w=500&q=80"
                    alt="Channel"
                    className="w-full h-[200px] object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute top-2 right-2 bg-red-500 px-2 py-1 rounded text-xs animate-pulse-slow">LIVE</div>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold mb-1">Somali National TV</h3>
                  <p className="text-sm text-gray-400">Now Playing: Evening News</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 border-t border-gray-800 py-12 animate-fade-in" style={{ animationDelay: '1200ms' }}>
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="animate-slide-up">
              <div className="flex items-center mb-4">
                <Film className="w-8 h-8 text-red-500" />
                <span className="ml-2 text-2xl font-bold">SoomaaliFilm</span>
              </div>
              <p className="text-gray-400">Your premier destination for Somali entertainment.</p>
            </div>
            {[
              {
                title: 'Quick Links',
                links: ['Movies', 'TV Shows', 'Live TV', 'Premium']
              },
              {
                title: 'Support',
                links: ['FAQ', 'Help Center', 'Contact Us', 'Terms of Service']
              }
            ].map((section, sectionIndex) => (
              <div
                key={section.title}
                className="animate-slide-up"
                style={{ animationDelay: `${1300 + sectionIndex * 100}ms` }}
              >
                <h3 className="font-semibold mb-4">{section.title}</h3>
                <ul className="space-y-2 text-gray-400">
                  {section.links.map((link, index) => (
                    <li key={link}>
                      <a
                        href="#"
                        className="hover:text-red-500 transition-all duration-300 transform hover:translate-x-2 inline-block"
                      >
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
            <div className="animate-slide-up" style={{ animationDelay: '1500ms' }}>
              <h3 className="font-semibold mb-4">Connect With Us</h3>
              <p className="text-gray-400 mb-4">Follow us on social media for updates and news.</p>
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-red-500 transition-all duration-300 transform hover:scale-110">
                  <span className="sr-only">Facebook</span>
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400 animate-fade-in" style={{ animationDelay: '1600ms' }}>
            <p>&copy; 2024 SoomaaliFilm. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;